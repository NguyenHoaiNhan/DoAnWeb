<section class="home-section">
  <h1 style="text-align: center;">Welcome To QuickQuiz</h1>
</section>